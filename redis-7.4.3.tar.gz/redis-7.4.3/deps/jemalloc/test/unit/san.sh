#!/bin/sh

export MALLOC_CONF="san_guard_large:1,san_guard_small:1"
